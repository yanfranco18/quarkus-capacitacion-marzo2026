package pe.nttdata.aps.producerservice.dto;

public record VoteRequest(
    String voterId,
    String pollId,
    String optionId,
    String email
) {
}
