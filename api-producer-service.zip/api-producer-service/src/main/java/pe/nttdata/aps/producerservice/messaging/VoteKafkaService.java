package pe.nttdata.aps.producerservice.messaging;

import com.nttdata.apps.avro.VoteEvent;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.kafka.clients.producer.Producer;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.jboss.logging.Logger;
import pe.nttdata.aps.producerservice.dto.VoteRequest;

@ApplicationScoped
public class VoteKafkaService {

  private static final Logger LOGGER = Logger.getLogger(VoteKafkaService.class);

  @Inject
  @Named("producer")
  Producer<String, VoteEvent> producer;

  public void sendVote(VoteRequest request) {
    VoteEvent voteEvent = toEvent(request);

    ProducerRecord producerRecord = new ProducerRecord<>(
        "votes-topic",
        voteEvent
    );

    producer.send(producerRecord, (metadata, exception) -> {
      if (exception != null) {
        LOGGER.info("### Error al enviar evento a kafka" + exception.getMessage());
      } else {
        LOGGER.infof("### Evento enviado a kafka topic=%s, partition=%s, offset=%d",
            metadata.topic(), metadata.partition(), metadata.offset());
      }
    });
  }

  private VoteEvent toEvent(VoteRequest request) {
    return new VoteEvent(
        request.voterId(),
        request.pollId(),
        request.optionId(),
        request.email()
    );
  }
}
