package pe.nttdata.aps.producerservice.service;

import jakarta.enterprise.context.ApplicationScoped;
import jakarta.inject.Inject;
import org.jboss.logging.Logger;
import pe.nttdata.aps.producerservice.dto.VoteRequest;
import pe.nttdata.aps.producerservice.messaging.VoteKafkaService;

@ApplicationScoped
public class VoteService {

  public static final Logger LOGGER = Logger.getLogger(VoteService.class);

  @Inject
  VoteKafkaService voteKafkaService;

  public void sendVote(VoteRequest voteRequest) {
    LOGGER.info(voteRequest);

    voteKafkaService.sendVote(voteRequest);
  }
}
