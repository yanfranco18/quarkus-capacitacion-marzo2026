package pe.nttdata.aps.producerservice.resources;

import jakarta.inject.Inject;
import jakarta.ws.rs.POST;
import jakarta.ws.rs.Path;
import jakarta.ws.rs.core.Response;
import pe.nttdata.aps.producerservice.dto.VoteRequest;
import pe.nttdata.aps.producerservice.service.VoteService;

@Path("/api/v1/votes")
public class VoteResource {

  @Inject
  VoteService voteService;

  @POST
  public Response createVote(VoteRequest request) {
    voteService.sendVote(request);
    return Response.accepted().build();
  }
}
