package pe.nttdata.aps.producerservice.messaging;

import com.nttdata.apps.avro.VoteEvent;
import io.quarkus.runtime.StartupEvent;
import jakarta.enterprise.context.ApplicationScoped;
import jakarta.enterprise.event.Observes;
import jakarta.inject.Inject;
import jakarta.inject.Named;
import org.apache.kafka.clients.consumer.Consumer;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.jboss.logging.Logger;

import java.time.Duration;
import java.util.Collections;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@ApplicationScoped
public class VoteKafkaService {

  private static final Logger LOGGER = Logger.getLogger(VoteKafkaService.class);
  private final ExecutorService executor = Executors.newVirtualThreadPerTaskExecutor();

  @Inject
  @Named("consumer")
  Consumer<String, VoteEvent> consumer;
  boolean running = true;

  public void initialize(@Observes StartupEvent event) {
    LOGGER.info("### Init...");
    consumer.subscribe(Collections.singletonList("votes-topic"));
    executor.submit(() -> {
      while (running) {
        try {
          var records = consumer.poll(Duration.ofSeconds(1));
          if (!records.isEmpty()) {
            records.forEach(record ->
                executor.submit(() -> {
                  processRecord(record);
                }));
          }
        } catch (Exception e) {
          LOGGER.error("Error al procesar eventos de kafka", e);
        }
      }
    });
  }

  public void processRecord(ConsumerRecord<String, VoteEvent> record) {
    var voteEvent = record.value();
    LOGGER.infof("### VoteId %s", voteEvent.getVoterId());
    // TODO: Implementar base de datos

  }
}
